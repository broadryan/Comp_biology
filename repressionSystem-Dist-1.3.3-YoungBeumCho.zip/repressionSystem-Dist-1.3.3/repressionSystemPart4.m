(*Part 4: Parameter inference.*)
(* inferParameters takes a list of expression profiles and a 
   matched list of genePresenceMasks, one for each strain that we have an expression 
   profile for. For each profile-mask pair, it makes a set of equations with the c parameters
   as unknown variables. It is important that the the right-hand-side of each equation be zero.
   A vector of the left-hand-sides of these equations is then dotted with itself to make a
   sum of squared errors, where the error is the deviation from zero. NMminize is then used to 
   find values of the c[i,j] parameters that are consistent with the equations, or as close to
   consistent as possible. We must use NMiminize instead of NSolve because the number of 
   equations may be larger than the number of variables and NSolve won't accept over-determined 
   system of equations.
   
   IMPORTANT: TO GET THE EXPECTED RESULTS ON ALL THE TESTS, PASS NMINIMIE CONSTRAINTS THAT
   FORCE ALL b AND c PARAMETERS TO LIE IN THE CLOSED INTERVVALE [0, 1]. *)

inferParameters[regulatorsMask_, geneExpressionProfiles_, genePresenceMasks_]:=
	(*Make sure b, c, m are undefined here and in all functions called from here.*)
	Block[{b, c, m},
	 ]


(* parameterEqns replaces the symbolic mRNA expression levels of the generic equations with actual values
   from a gene expression matrix, returning a final set of equations with fixed mRNA levels but variables
   for parameters. Solving these for the parameter variables yields a set of parameters that
   are consistent with the expression levels.*)

parameterEqns[eqns_, geneExpressionProfile_]:=

parameterSumSquaredError[eqns_]:=
		
(*SECTION Some auxiliary functions to support testing parameter inference.*)

(* Generate a random set of parameters, generate expression profiles for those 
   parameters in wild-type cells and cells with all genes deleted one at a time.
   Then use these expression levels to infer the parameters. Compare the inferred 
   parameters to the ones used to generate the expression levels. If the 
   difference is less than or equal to 10^-4 replace it by zero. Return the resulting matrix of differences. 
   
   It should contain nothing but zeros.*)		 

testParameterInference[n_, seed_]:=
	With[{regulatorsMask=ConstantArray[1, {n}],
		  genePresenceMasks=allSinglesAndWTPresenceMatrix[n]},
		With[{params=generateRandomParams[regulatorsMask, seed]},
			With[{expressionMatrix=expressionMatrix[params, genePresenceMasks]},
				With[{diff=params-inferParameters[regulatorsMask,
					 	                  		  expressionMatrix,
					 	     			          genePresenceMasks]},
				Round[diff, 0.0001]
				]]]]

allSinglesAndWTPresenceMatrix[n_]:=
	Join[ConstantArray[1,{1,n}],
		 ConstantArray[1, {n,n}] - IdentityMatrix[n]]
		 
