(* Mathematica Raw Program *)

generateRandomParams[regulatorsMask_, seed_]:=
	Module[{MaskL = Length[regulatorsMask], bV, cM, i, j},

		bV = ConstantArray[0.0,MaskL];
		cM = ConstantArray[0.0,{MaskL,MaskL}];
		SeedRandom[seed];
		Do[
			bV[[i]] = RandomReal[{.1,1}];
			
			Do[
				If[i != j && regulatorsMask[[i]] == 1,
					cM[[i,j]] = RandomReal[]
				];
			,{j,MaskL}];
			
		,{i,MaskL}];

	{bV,cM}
]

(* mutantExpVars returns a list of variables representing the expression levels of
   genes that remain in the genotype described by genePresenceMask. *)
mutantExpVars[genePresenceMask_]:=
	Module[{MaskL = Length[genePresenceMask], i, return = {}}, 
		Do[
			If[genePresenceMask[[i]] == 1,AppendTo[return,m[i]]];
		,{i,MaskL}];
		return
]

(* genericEqns generates system of equations for n mutually repressing proteins. They are
   generic in that the parameters remain as indexed symbols b[j] and c[j,i], except that
   c[i,i] is replaced by zero, implementing the ban on auto-repression.*)

genericEqns[n_]:=
	Module[{eqn=ConstantArray[0,n], i, j},
		Clear[b];Clear[m];Clear[c];
		
		Do[
			eqn[[i]] = (b[i]m[i] Product[ If[ i != j, m[j] c[j,i] + 1, 1], {j, n}] - 1.0 == 0);	
		,{i,n}];
	eqn
	]

(* mutantEqns takes a genePresenceMask indicating which genes were deleted in the cells 
   in which these mRNA measurements were taken. It generates a set of generic equations 
   and then replaces the mRNA level variables for the deleted genes with zeros, ensuring 
   that any actual measurments made on those deleted genes are ignored and any solver 
   doesn't have to deal with them.
*)



mutantEqns[genePresenceMask_]:=
Module[{MaskL = Length[genePresenceMask], eqn, i, return = {}},
	eqn = genericEqns[MaskL];

	Do[
		If[genePresenceMask[[i]] == 0, m[i] = 0, AppendTo[return,eqn[[i]]]];
	
	,{i,MaskL}];

	return
]


(* expressionEqns replaces the symbolic parameters of the generic equations with actual values
   from a parameter matrix, returning a final set of equations with fixed parameters but variables
   for mRNA levels. Solving these for the mRNA variables yields a set of expression levels that
   are consistent with the parameters.*)
expressionEqns[eqns_, {bVector_, cMatrix_}]:=
Module[{i,j},
	Do[
		b[i] = bVector[[i]];
		
		Do[
			c[j,i] = cMatrix[[j,i]]
			
		,{j,Length[cMatrix[[i]]]}]
		
	,{i,Length[bVector]}];
	
	eqns
]
(* expressionProfile finds a set of steady state mRNA expression levels that are consistent with
   a set of expression equations and a genotype as indicated by genePresenceMask. To do this, you
   will use the built in function FindRoot to find a solution to the set of simultaneous equations
   you have constructed with the function expressionEqns. IMPORTANT: FindRoot allows you to specify
   a starting, minimum, and maximum value for each unknown (in this case the mRNA levels). You need
   to do this, making use of the bounds specified in the Introduction section of the assignment notebook. 
   
   The result of FindRoot is a list of replacement rules for expression variables. These are then used 
   to construct a vector of length n containing the expression levels for genes that are present and 
   zeros for genes that are deleted.*)
expressionProfile[expressionEqns_, genePresenceMask_]:=
Module[{temp={},return},
	
	Map[(AppendTo[temp,{#,1,0,100}]) &, mutantExpVars[genePresenceMask]];
	
	return = FindRoot[expressionEqns,temp];
	
	return
]
(* expressionMatrix takes parameters and a list of genePresenceMasks, one for each strain that we
   want an expression profile for. For each mask, it makes a set of equations and calls
   expressionProfile with those equations and the mask. This returns a list of rules that is
   applied to the expression level variables to produce actual values, which are returned.
   The return value is a matrix in which each row represents the expression levels for one
   strain (as described by one genePresenceMask). *)
expressionMatrix[params_, genePresenceMasks_]:=
	Module[{return = {}, mV, temp, i},	
	(*This ensures that b, c, m are undefined here and in all functions called from here.*)
		Block[{b, c, m},
			Map[(mV = expressionProfile[expressionEqns[mutantEqns[#], params],#];
			temp = Table[m[i],{i,Length[#]}];
			AppendTo[return,temp/.mV]) &, genePresenceMasks];	
		];
	return
]	