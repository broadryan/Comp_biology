
(*A draw is the series of rolls between the time a die is drawn from the bag and the time it is returned to the bag.
  dicePosterior calculates the posterior probability of a type1 versus type2 die, based the number of times each face
  appears in the draw and the relative numbers of Type 1 and Type 2 dice in the bag as well as the face probabilities
  for Type 1 and Type 2 dice. The single number returned is the posterior probability of Type 1.
  
  You will need to catch the case where the probability of a face showing is zero and it shows zero times. 0^0 is undefined,
  but there is a simple intuitive number that you should use in this case.
  *)
  
(*binCounts = list of the number of times each face has shown up during this draw
e.g. {5, 3, 5, 7} mean 5 ones, 3 twos, 5 threes, and 7 fours.
Length[binCounts] = Length[faceProbs1] = Length[faceProbs2]

0 <= type1Prior, type2Prior <= 1
are vectors representing the probability of producing each face on each type of die
 		
Input example: 
dicePosterior[{5, 3, 5, 7}, 0.4, 0.6, {0.25, 0.25, 0.25, 0.25}, {0.1, 
  0.1, 0.1, 0.7}]
  
  From test:
  1)If 0 * something occurs, keep it.
  2)If 0^0 occurs, consider it as 1
  3)If marginalProb=0, data is rigged*)

dicePosterior[binCounts_, type1Prior_, type2Prior_, faceProbs1_, faceProbs2_] :=
Module[{ totalThrow = Total[binCounts], totalFactorial, i, 
		 mappedBin, mappedDenom, firstTerm, secondTerm1 = {}, secondTerm2 = {}, 
		 likelihood1, likelihood2, marginalProb, posteriorProb}, 
		 
		totalFactorial = Factorial[totalThrow]; (* numerator for likelhood1 and 2 calculation*)
		mappedBin = Map[Factorial,binCounts];
		mappedDenom = Apply[Times, mappedBin]; (* denominator for likelihood1 and 2 calculation *)
		firstTerm = totalFactorial / mappedDenom; (*numerator / denominator from above, is the first term*)
		
		
		For[i = 1, i <= Length[binCounts], i++,
			AppendTo[secondTerm1, 
				If[ binCounts[[i]] == 0 && faceProbs1[[i]] == 0, 1, (* define 0^0 = 1 *)
					faceProbs1[[i]]^binCounts[[i]]						
				]
			]; (*second term to multiply for likelihood1 caclulation created as a list*)
			
			AppendTo[secondTerm2, 
				If[ binCounts[[i]] == 0 && faceProbs2[[i]] == 0, 1,
					faceProbs2[[i]]^binCounts[[i]]						
				]
			]
		]; (*second term to multiply for likelihood2 caclulation created as a list*)
		
		secondTerm1 = Apply[Times, secondTerm1]; (*second term to multiply for likelihood1 caclulation created as a single real number*)
		secondTerm2 = Apply[Times, secondTerm2];(*second term to multiply for likelihood2 caclulation created as a single real number*)
		
 		likelihood1 = firstTerm * secondTerm1; (* likelihood probability for dice1 calculated *)
 		likelihood2 = firstTerm * secondTerm2; (* likelihood probability for dice2 calculated *)
 		
 		marginalProb = (type1Prior * likelihood1) + (type2Prior * likelihood2);	 (* marginal probability, same for dice 1 and 2, calculated *)
		
		
		
		If[marginalProb == 0, Print["Incorrect input of binCounts or dice used doesn't match prior observance"],
		   posteriorProb = (type1Prior * likelihood1) / marginalProb (* Posterior probability for dice1, calculated *) (* Return result *)]
		
 	
 	] 
 	