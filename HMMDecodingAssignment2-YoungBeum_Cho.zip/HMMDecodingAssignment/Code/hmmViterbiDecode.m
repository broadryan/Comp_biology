(* decode
INPUT 
- observationSeq, in the form output by readFasta in tools.m
- hmm, in form output by readHMM in tools.m.
See tools.m for details.
     
OUTPUT
- stateSeq = a list containing the most likely state sequence, e.g., {h,h,m,m,m}.  
The length of this sequence equal to the length to the input observationSeq.  

IMPLEMENTATION
I recommend the following:
1) Implement the Viterbi table as a matrix that is transposed relative to the way
   it is shown in class and course notes. In other words, the rows correspond to
   observations and the columns to states.
2) After computing the Viterbi probabilities for each observation, normalize
   them by dividing by their sum. The matrix entries are no longer the Viterbi 
   probabilities, but the entries for each observation remain proportional
   to the Viterbi probabilities. The only thing you will use this matrix for is picking
   the state with the greatest entry for each observation, so scaling them all by a
   constant factor won't change the result. The benefit of doing this is that you
   avoid numerical underflow.
*)

viterbiDecode[observationSeq_, hmm_] :=
  Module[{nS},
  (* Put your code here. *)
	nS = traceback[observationSeq, hmm];
  	nS = Replace[nS, 1 -> "m", {1}];
	nS = Replace[nS, 2 -> "h", {1}];
  (* Return the sequence of state names corresponding to the Viterbi decode path. *)
  nS
 ]



buildMatrix[observationSeq_, hmm_] := 
	Module[{numberOfObservations = Length[observationSeq], nO, numberOfStates = Length[hmm["states"]], nS,
		 vM, viterbiMatrix, observationIndex,i,j,k,prob},
	  (* Put your code*)
	nO = numberOfObservations;
	nS = numberOfStates;
	vM = Table[0.,{nO},{nS}];
	
	Do[
		vM[[1,i]] = hmm["initialStateProbs"][[i]]*hmm["emissionMatrix"][[observationSeq[[1]],i]];
		,{i,nS}
	];
	vM[[1]] = norm[vM[[1]]];
	
	Do[
		Do[
			prob = Table[hmm["transitionMatrix"][[k,i]] * vM[[j-1,k]],{k,nS}];
			observationIndex = observationSeq[[j]];
			vM[[j,i]] = hmm["emissionMatrix"][[observationIndex,i]] * Max[prob];
			,{i,nS}
		];
		vM[[j]] = norm[vM[[j]]];
		,{j,Range[2,nO]}
	];
	
	viterbiMatrix = vM;
	 (* Return*)
	viterbiMatrix] 



norm[v_] := 
	Module[{},
		If[Total[v]==0,v/Total[v],Normalize[v,Total]]
	]


	
traceback[viterbiMatrix_, hmm_] :=
  (* Put 2your code for tracing back through the Viterbi matrix here. To give you an idea of what to expect,
     my code is 10 lines. But use as many lines as you need to make your code clear and readable. *)
	Module[{stateSeq,sL = Length[viterbiMatrix],nS = Length[hmm["states"]],i,j,prob},
		stateSeq = Table[0,sL];
		
		stateSeq[[sL]] = Ordering[viterbiMatrix[[sL]],-1][[1]];
		
		Do[
			prob = Table[viterbiMatrix[[j,i]]*hmm["transitionMatrix"][[i,stateSeq[[j+1]]]],{i,nS}];	
			stateSeq[[j]] = Min[Ordering[prob,-1]];	
			,{j,sL-1,1,-1}
		];	
	 (* Return the list of states. *)
	 stateSeq
	]
 
	